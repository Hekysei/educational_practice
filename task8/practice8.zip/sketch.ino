#include "Adafruit_NeoPixel.h"

#define LED_PIN  3
#define NUMPIXELS 64 
#define BUTTON_PIN 2 

Adafruit_NeoPixel strip (NUMPIXELS, LED_PIN, NEO_GRB + NEO_KHZ800);

void SnakeStep() {
  static int i = 0;
  static int mode = 0;

  if (i == NUMPIXELS){
    i = 0;
    mode = (mode+1)%3;
  }

  // strip.Color(255, 0, 0)
  uint32_t color = 255;
  color<<=mode*8;

  strip.setPixelColor(i, color);

  i++;
}

void setup() {
   strip.begin();            
   strip.setBrightness(255);
}

bool last_button_state = false;

void loop() {
  bool button_state = digitalRead(BUTTON_PIN);
  if (button_state == HIGH && last_button_state == LOW) {
    delay(5000);
  }
  last_button_state = button_state;
  
  
  SnakeStep();
  strip.show();
  delay(50);
}
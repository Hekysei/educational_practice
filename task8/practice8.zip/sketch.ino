#include "Adafruit_NeoPixel.h"

#define LED_PIN  3
#define NUMPIXELS 64 
#define BLUE_BUTTON_PIN 4
#define YELLOW_BUTTON_PIN 2
  // strip.Color(0, 0, 255)
#define BLUE (uint32_t)255

Adafruit_NeoPixel strip (NUMPIXELS, LED_PIN, NEO_GRB + NEO_KHZ800);

// SNAKE ANIMATION
void SnakeInit(size_t i) {
  int mode = (i/NUMPIXELS)%3;
  i%=NUMPIXELS;
  int prev_mode = (mode+2)%3;

  uint32_t color = BLUE<<(mode*8);
  for (int j = 0; j<NUMPIXELS; j++){
    strip.setPixelColor(j, color);
    if (j==i)
      color = BLUE<<(prev_mode*8);
  }
}
void SnakeStep(size_t i) {
  int mode = (i/NUMPIXELS)%3;
  i%=NUMPIXELS;

  strip.setPixelColor(i, BLUE<<(mode*8));
}

void LOLInit(size_t i) {}
void LOLStep(size_t i) {
  uint32_t color_on = 0x00FF0000;
  uint32_t color_off = 0;
  for (int j = 0; j<NUMPIXELS; j++){
    bool is_on = false;
      int y = j/8;
      if (y!=0 && y!=7){
        int x = j%8;
        if (y%2==0)
          x=7-x;
        x+=i;
        x%=13;
        
        if (y==6){
          if (x%4!=0)
            is_on = true;
        }
        else if (y == 1) {
          if (x%8==1 || (x>=5 && x<=7))
            is_on = true;
        }
        else {
          if (x%2==1 && (x%4==1 || x==7))
            is_on = true;
        }
      }



      strip.setPixelColor(j, (is_on) ? color_on : color_off);
  }
}


void setup() {
   strip.begin();            
   strip.setBrightness(255);
   pinMode(BLUE_BUTTON_PIN, INPUT_PULLUP);
   pinMode(YELLOW_BUTTON_PIN, INPUT_PULLUP);
}

size_t i = 0;
int matrix_mode = 1;

void loop() {
  bool blue_button_state = digitalRead(BLUE_BUTTON_PIN);
  bool yellow_button_state = digitalRead(YELLOW_BUTTON_PIN);

  if (yellow_button_state == LOW){
    matrix_mode = 1;
    LOLInit(i);
  }

  else if (blue_button_state == LOW) {
    matrix_mode = 0;
    SnakeInit(i);
  }
  
  
  if (matrix_mode == 0)
    SnakeStep(i);
  else
    LOLStep(i);

  strip.show();
  delay(70);
  i++;
}
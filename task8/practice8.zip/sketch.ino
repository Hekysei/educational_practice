#include "Adafruit_NeoPixel.h" // подключаем библиотеку

#define PIN  3              // указываем пин для подключения ленты
#define NUMPIXELS 64  // указываем количество светодиодов в ленте

// создаем объект strip с нужными характеристиками
Adafruit_NeoPixel strip (NUMPIXELS, PIN, NEO_GRB + NEO_KHZ800);

void setup() {
   strip.begin();                     // инициализируем ленту
   strip.setBrightness(50);  // указываем яркость светодиодов (максимум 255)
}

void loop() {

   // поочередно включаем красный цвет
   for (int i = -1; i < NUMPIXELS; i++) {
      strip.setPixelColor(i, strip.Color(255, 0, 0));
      strip.show();
      delay(10);
   }

   // поочередно включаем зеленый цвет
   for (int i = -1; i < NUMPIXELS; i++) {
      strip.setPixelColor(i, strip.Color(0, 255, 0));
      strip.show();
      delay(10);
   }

   // поочередно включаем синий цвет
   for (int i = -1; i < NUMPIXELS; i++) {
      strip.setPixelColor(i, strip.Color(0, 0, 255));
      strip.show();
      delay(10);
   }

}
#include "Adafruit_NeoPixel.h"

#define LED_PIN  3
#define NUMPIXELS 64 
#define BUTTON_PIN 2
  // strip.Color(0, 0, 255)
#define BLUE (uint32_t)255

Adafruit_NeoPixel strip (NUMPIXELS, LED_PIN, NEO_GRB + NEO_KHZ800);

void SnakeInit(size_t i) {
  i%=NUMPIXELS*3;
  int mode = i/(NUMPIXELS);
  int prev_mode = (mode+2)%3;
  i%=NUMPIXELS;

  uint32_t color = 0;
  
  color = BLUE<<(mode*8);
  for (int j = 0; j<=i; j++)
    strip.setPixelColor(j, color);

  color = BLUE<<(prev_mode*8);
  for (int j = i+1; j<NUMPIXELS; j++)
    strip.setPixelColor(j, color);
}

void SnakeStep(size_t i) {
  i%=NUMPIXELS*3;
  int mode = i/(NUMPIXELS);
  i%=NUMPIXELS;

  strip.setPixelColor(i, BLUE<<(mode*8));
}

void setup() {
   strip.begin();            
   strip.setBrightness(255);
}

bool last_button_state = false;
size_t i = 0;
int matrix_mode = 0;

void loop() {
  bool button_state = digitalRead(BUTTON_PIN);
  if (button_state == HIGH && last_button_state == LOW) {
    matrix_mode = (matrix_mode+1)%2;
    if (matrix_mode == 0)
      SnakeInit(i);
    else
      delay(50);
  }
  last_button_state = button_state;
  
  if (matrix_mode == 0)
    SnakeStep(i);
  else
    delay(50);

  strip.show();
  delay(50);
  i++;
}
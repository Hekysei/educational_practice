#include <Servo.h>

void setup() {
  Serial.begin(115200);
  Serial.println("Введите угол от 0 до 180:");
}

void loop() {
  String input = Serial.readStringUntil('\n');
  input.trim();
  if (input=='\n')
    return;

  bool valid = true;
  if (input.length() < 1 && input.length() > 3) {
    valid = false;
  } else {
    for (size_t i = 0; i < input.length(); i++) {
      if (!isDigit(input[i])) {
        valid = false;
        break;
      }
    }
  }

  if (valid) {
    int32_t target = input.toInt();
    if (target >= 0 && target <= 180) {
      Serial.println("Позиция достигнута.");
    } else {
      Serial.println("Ошибка: Допускаются только значения от 0 до 180.");
    }
  } else {
    Serial.println("Ошибка: Ввод должен быть строго числом.");
  }
}
